/*************************************************************************\
 Estructura de juego con varias pantallas.
\*************************************************************************/

#include <iostream>
using namespace std;

int main()
{
  bool salir_del_juego = false;
  bool gameover;
  bool ganaste = false;

  int opcion;   // Para el menú principal
  int eleccion; // Para las elecciones del juego

  while (!salir_del_juego)
  {
    do
    {
      system("clear");
      for (int i = 0; i < 11; i++) 
 {cout <<   "                                                                                                                        " << endl;}   //120 caracteres
       
  cout <<   "                                                                                                                        " << endl;
  cout <<   "            ██████╗ █████╗ ███╗   ███╗██╗███╗   ██╗ ██████╗      █████╗      ██████╗ █████╗ ███████╗ █████╗             " << endl;  
  cout <<   "           ██╔════╝██╔══██╗████╗ ████║██║████╗  ██║██╔═══██╗    ██╔══██╗    ██╔════╝██╔══██╗██╔════╝██╔══██╗            " << endl;
  cout <<   "           ██║     ███████║██╔████╔██║██║██╔██╗ ██║██║   ██║    ███████║    ██║     ███████║███████╗███████║            " << endl;
  cout <<   "           ██║     ██╔══██║██║╚██╔╝██║██║██║╚██╗██║██║   ██║    ██╔══██║    ██║     ██╔══██║╚════██║██╔══██║            " << endl;
  cout <<   "            ██████╗██║  ██║██║ ╚═╝ ██║██║██║ ╚████║╚██████╔╝    ██║  ██║    ╚██████╗██║  ██║███████║██║  ██║            " << endl;
  cout <<   "            ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝     ╚═╝  ╚═╝     ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝            " << endl;
    for (int i = 0; i < 4; i++) 
 {cout <<   "                                                                                                                        " << endl;}   //120 caracteres
    //cout << "       ___________________________________________________________________________________________  " << endl;
    cout << "                                                  1.    Jugar                                                           " << endl;
    cout << "                                                  2.   Creditos                                                         " << endl;
    cout << "                                                  3.    Salir                                                           " << endl;
    cout << "                                                                                                                        " << endl;
    cout << "                                                                                                                        " << endl;
    cout << "                                                                                                                        "<< endl;
    cout << "                                          Elegí una opción:       " ; cin >> opcion;
    
      switch (opcion)
      {
      case 1:
        system("clear");
        
        for (int i = 0; i < 3; i++) 
        {cout << "                                                                                                                        " << endl;}
         cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
         cout << "           |       ────────────────                                 *                                        |          " << endl;
         cout << "           |      | MORENO, 03:32AM |                        *                                               |          " << endl;
         cout << "           |       ────────────────         *                                                  █████         |          " << endl;
         cout << "           |      ☼    *                                    *   ( )                 *         ███████      * |          " << endl;
         cout << "           |                           *            *           | |          *                ███████        |          " << endl;
         cout << "           |                                        *           | |                            █████         |          " << endl;
         cout << "           |      *        ____________     ____________        | |                *                *        |          " << endl;
         cout << "           |              │            │ • │            │\\      | |   ________                *              |          " << endl;
         cout << "           |              │  ╔╗╔╗╔╗╔╗  │   │ ██  ██  ██ │ \\     | |   │      │                               |          " << endl;
         cout << "           |        *     |  ╚╝╚╝╚╝╚╝  │   │ ██  ██  ██ │  │    | |   │ 0  0 │     ____________       *      |          " << endl;
         cout << "           |              │  ╔╗╔╗╔╗╔╗  │   │            │  │    | |   │ 0  0 │    │            │\\            |          " << endl;
         cout << "           |              │  ╚╝╚╝╚╝╚╝  │   │ ██  ██  ██ │  │    | |   │ 0  0 │    │ ██  ██  ██ │  |    *     |          " << endl;
         cout << "           |              │            │   │            │  │    | |   │      |    │            │  |          |          " << endl;
         cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
         cout << "                                                                                                                        " << endl;
         cout << "                                                                                                                        " << endl;
         cout << "                                                                                                                        " << endl;
         cout << "                                                                                                                        " << endl;
         cout << "                                                                                                                        " << endl;
         cout << "                                                                                                                        " << endl;
         cout << "                          Luego de una larga noche en el conurbano bonaerense, toca volver a casa                       " << endl;
         cout << "                                                                                                                        " << endl;
         for (int i = 0; i < 5; i++) 
        {cout << "                                                                                                                        " << endl;}
         cout << " presiona ENTER para continuar.."; cin.ignore().get();
        break;
      case 2:
        system("clear");
        cout << "Juego hecho e ideado por Juan Cruz Rivero, Tobias Gorschin, Nilo, Camila Jara." << endl;
        cin.ignore().get();
        break;
      case 3:
        system("clear");
        cout << "Ha decidido salir del juego..." << endl;
        cin.ignore().get();
        salir_del_juego = true;
        break;
    
      default:
        system("clear");
        cout << "Introduzca una opción válida." << endl;
        cin.ignore().get();
        break;
      }
    } while (opcion != 1 && opcion != 2);

    if (opcion == 1) {
      gameover = false;
      while (!gameover)
      {
        //-------------------------- Pantalla 0 ---------------------------
        do
        {
          system("clear");
          for (int i = 0; i < 3; i++) 
         {cout << "                                                                                                                        " << endl;}
          cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
          cout << "           |       ────────────────                                 *                                        |          " << endl;
          cout << "           |      | MORENO, 03:32AM |                        *                                               |          " << endl;
          cout << "           |       ────────────────         *                                                  █████         |          " << endl;
          cout << "           |      ☼    *                                    *   ( )                 *         ███████      * |          " << endl;
          cout << "           |                           *            *           | |          *                ███████        |          " << endl;
          cout << "           |                                        *           | |                            █████         |          " << endl;
          cout << "           |      *        ____________     ____________        | |                *                *        |          " << endl;
          cout << "           |              │            │ • │            │\\      | |   ________                *              |          " << endl;
          cout << "           |              │  ╔╗╔╗╔╗╔╗  │   │ ██  ██  ██ │ \\     | |   │      │                               |          " << endl;
          cout << "           |        *     |  ╚╝╚╝╚╝╚╝  │   │ ██  ██  ██ │  │    | |   │ 0  0 │     ____________       *      |          " << endl;
          cout << "           |              │  ╔╗╔╗╔╗╔╗  │   │            │  │    | |   │ 0  0 │    │            │\\            |          " << endl;
          cout << "           |              │  ╚╝╚╝╚╝╚╝  │   │ ██  ██  ██ │  │    | |   │ 0  0 │    │ ██  ██  ██ │  |    *     |          " << endl;
          cout << "           |              │            │   │            │  │    | |   │      |    │            │  |          |          " << endl;
          cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                                       ¿En que volves?                                                  " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                          1.           Vuelvo caminando                                                 " << endl;
          cout << "                                          2.       Voy a la estacion de tren                                            " << endl;
         // cout << "                                          3.     Voy a la parada del colectivo                                          " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                                                                                                        " << endl;
          cout << "                                                                                                                        "<< endl;
          cout << "                                          Elegí una opción:       " ; cin >> eleccion;
          cout << "                                                                                                                        " << endl;
          cout << "                                                                                                                        " << endl;
          for (int i = 0; i < 5; i++) 
         {cout << "                                                                                                                        " << endl;}
        } while (eleccion != 1 && eleccion != 2 && eleccion != 3);

        //-------------------------- Pantalla 1 ---------------------------
        if (eleccion == 1)
        {
            system("clear");
            for (int i = 0; i < 3; i++) 
  {cout << "                                                                                                                        " << endl;}
   cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
   cout << "           |       ────────────────    █     █   █  ██████████████████████████  █    █      █      █      █  |          " << endl;
   cout << "           | ▒▒▒  | MORENO, 04:13AM |  █▒▒▒▒▒█▒▒▒█▒▒██████████████████████████▒▒█▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒   ────────────────    █▒▒▒▒▒█▒▒▒█▒▒██████████████████████████▒▒█▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒ █      █      █       █▒▒▒▒▒█▒▒▒█▒▒██████████████████████████▒▒█▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒█▒▒▒█▒▒/                         | █▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒█▒▒▒█▒/             |             |█▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒█▒▒▒█/                             |▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒█▒▒▒/               |               |▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒█▒▒/                |                |▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒█▒/                                   |▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒█/                  |                  |█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | ▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒/                   |                   |▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒▒▒▒▒█▒▒|          " << endl;
   cout << "           | _______________________________/                    |                    |______________________|          " << endl;
   cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
   cout << "                                                                                                                        " << endl;
   cout << "                                                                                                                        " << endl;
   cout << "                                                                                                                        " << endl;
   cout << "                                                                                                                        " << endl;
   cout << "                                                                                                                        " << endl;
   cout << "                                                                                                                        " << endl;
   cout << "                             Luego de un largo rato caminando, te encontras un callejon sin salida                      " << endl;
   cout << "                                                                                                                        " << endl;
   for (int i = 0; i < 5; i++) 
  {cout << "                                                                                                                        " << endl;}
      cout << " presiona ENTER para continuar.."; cin.ignore().get();

     gameover = true;   }
          // Pantalla 1.2
          
        //-------------------------- Pantalla 2 ---------------------------
        else if (eleccion == 2)
        {
          do
          {
            system("clear");
            cout << "         │      │     //                                                                                 │     │        " << endl;
            cout << "         │ ┌┬┐  │    /                                ────────────                                       │     │ \\      " << endl;
            cout << "         │ ├┼┤  │   /                                │            │                                      │     │ │\\     " << endl;
            cout << "         │ └┴┘  │  /      │             ────────────────────────────────────────                         │     │ │*\\    " << endl;
            cout << "         │ ┌┬┐  │  │      │            /                                        \\                        │     │ │**\\   " << endl;
            cout << "         │ ├┼┤  │  │     /│           / ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ \\                       │     │ │***\\│ " << endl;
            cout << "         │ └┴┘  │  │    / │          /                      ┌──────────────────┐  \\                      │     │ │****│ " << endl;
            cout << "         │ ┌┬┐  │  │   /  │          │ ▌  ─────────  /─\\    │ 0101 0 101 01 01 │▌ │                      │     │ │****│ " << endl;
            cout << "         │ ├┼┤  │  │  /   │          │ ▌ │         ││   │───│ 101 01 0 10 101 0│▌ │                      │     │ │****│ " << endl;
            cout << "         │ └┴┘  │  │ /    │          │ ▌ │         │ \\─/ ───└──────────────────┘▌ │                      │     │ │****│ " << endl;
            cout << "         │ ┌┬┐  │  │/     │          │ ▌ │─────────│┌─────────────────────────┐ ▌ │                      │     │ │****│ " << endl;
            cout << "         │ ├┼┤  │  │     /           │ ▌ │         ││                        ││ ▌ │                      │     │ │****│ " << endl;
            cout << "         │ └┴┘  │  │    /            │ ▌ │         ││                        ││ ▌ │                      │     │ │****│ " << endl;
            cout << "         │ ┌┬┐  │  │   /             │ ▌ │         ││                        ││ ▌ │                      │     │ \\****│ " << endl;
            cout << "         │ ├┼┤  │  │  /              │ ▌ │         ││                        ││ ▌ │          \\           │     │  \\***│ " << endl;
            cout << "         │ └┴┘  │  │ /               │ ▌ │         ││                        ││ ▌ │           \\          │     │ \\ \\**│ " << endl;
            cout << "         │ ┌┬┐  │  │/   /            │ ▌  ───────── └─────────────────────────┘ ▌ │            \\         │     │ │\\ \\*│ " << endl;
            cout << "         │ ├┼┤  │  /   /             │ ▌                                        ▌ │             \\        ││    │ │*\\ \\│ " << endl;
            cout << "         │ └┴┘  │     /              │ ▌                                        ▌ │              \\       ││    │ │**\\   " << endl;
            cout << "         │ ┌┬┐  │    /               │  ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  │               \\      │     │ │***\\│ " << endl;
            cout << "         │ ├┼┤  │   /                │                                            │                \\\\    │     │ │****│ " << endl;
            cout << "         │ └┴┘  │  /                 │                                            │                 \\    │     │ │****│ " << endl;
            cout << "         │ ┌┬┐  │ /                  │   ▬▬▬▬▬▬▬▬▬▬    ▬▬▬▬▬▬▬▬▬▬    ▬▬▬▬▬▬▬▬▬▬   │                  \\   │     │ │****│ " << endl;
            cout << "         │ ├┼┤  │/                   │                                            │                   \\  │     │ │****│ " << endl;
            cout << "         │ └┴┘  │                    │              ┌──────────────┐              │                    \\ │     │ │****│ " << endl;
            cout << "         │──────                     │     ▲        │**************│        ▲     │                     \\│     │ │****│ " << endl;
            cout << "         │                           │    ◄█►       └──────────────┘       ◄█►    │                      \\     │ │****│ " << endl;
            cout << "         │                           │   ◄███►                            ◄███►   │                       \\    │ \\****│ " << endl;
            cout << "        /│                           │    ◄█►         ▬▬▬▬▬▬▬▬▬▬▬▬         ◄█►    │                        \\   │  \\***│ " << endl;
            cout << "       / │                           │     ▼                                ▼     │                         \\  │   \\**│ " << endl;
            cout << "      /  │                            ───────────┬────┬──────────┬────┬───────────                           \\ │    \\*│ " << endl;
            cout << "     /   /                               │       │    │──────────│    │       │                               \\│     \\│ " << endl;
            cout << "        /                                │       │    │──────────│    │       │                                \\        " << endl;
            cout << "   /   /                     /           └───────┴────┴──────────┴────┴───────┘           \\                     \\       " << endl;
            cout << "  /   /                     /                ││││                       ││││               \\                     \\      " << endl;
            cout << " /   /                     /                 ││││───────────────────────││││                \\                     \\     " << endl;
            cout << " presiona ENTER para continuar.."; cin.ignore().get();

            system("clear");

            for (int i = 0; i < 3; i++) 
            {cout << "                                                                                                                        " << endl;}
             cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                 | |                           | |                            | |                 |          " << endl;
             cout << "           |               ───────                      ────────                        ───────               |          " << endl;
             cout << "           |              | Morón |                    | Flores |                      | Once  |              |          " << endl;
             cout << "           |               ───────                      ────────                        ───────               |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "           |                                                                                                  |          " << endl;
             cout << "            ─────────────────────────────────────────────────────────────────────────────────────────────────           " << endl;
             cout << "                                                                                                                        " << endl;
             cout << "                                                                                                                        " << endl;
             cout << "                                                                                                                        " << endl;
             cout << "                                                                                                                        " << endl;
             cout << "                                                                                                                        " << endl;
             cout << "                                      Logras subir al tren con exito, ¿En que estacion bajas?                                                  " << endl;
             cout << "                                                                                                                        " << endl;
             cout << "                                          1.                    Morón                                                            " << endl;
             cout << "                                          2.                   Flores                                               " << endl;
             cout << "                                          3.                    Once                                                   " << endl;
             cout << "                                                                                                                        " << endl;
            cout << "                                                                                                                        " << endl;
            cout << "                                                                                                                        "<< endl;
            cout << "                                          Elegí una opción:       " ; cin >> eleccion;
            cout << "                                                                                                                        " << endl;
            cout << "                                                                                                                        " << endl;
            for (int i = 0; i < 5; i++) 
            {cout << "                                                                                                                        " << endl;}
          } while (eleccion != 1 && eleccion != 2 && eleccion !=3);

          // Pantalla 2.1
          if (eleccion == 1 || eleccion == 2) {  
            gameover = true;
           } else if (eleccion == 3){
              ganaste = true; 
              gameover = true;
            }
          
        
        //-------------------------- Pantalla 3 ---------------------------
        else if (eleccion == 3)
        {
          
          
            cout << "Saliste con exito del juego";
        
        }
     }}

      if (ganaste){ system("clear");
        cout << "                                                                                                             " << endl;
            cout << "                                                                                    ٩(ˊᗜˋ*)و ♡                          " << endl;
            cout << "                                                                                                                    " << endl;
            cout << "               ____                       _       _                                                             " << endl;
            cout << "              / ___| __ _ _ __   __ _ ___| |_ ___| |                                                            " << endl;
            cout << "             | |  _ / _` | '_ \\ / _` / __| __/ _ \\ |                                                            " << endl;
            cout << "             | |_| | (_| | | | | (_| \\__ \\ ||  __/_|                                                            " << endl;
            cout << "              \\____|\\__,_|_| |_|\\__,_|___/\\__\\___(_)                                                            " << endl;
            cout << "                                                                                                                " << endl;
            cout << "                    Llegaste perfectamente a casa!                                                             " << endl;
            cout << "                                                                                        =====      /  \\         " << endl;
            cout << "                                                                                       _|___|_____/ __ \\____________ " << endl;
            cout << "                                                                                      |::::::::::/ |  | \\:::::::::::| " << endl;
            cout << "                                                                                      |:::::::::/  ====  \\::::::::::| " << endl;
            cout << "                                                                                      |::::::::/__________\\:::::::::| " << endl;
            cout << "                                                                                      |_________|  ____  |__________| " << endl;
            cout << "                                                                                       | ______ | / || \\ | _______ |  " << endl;
            cout << "                                                                                       ||  |   || ====== ||   |   ||  " << endl;
            cout << "                                                                                       ||--+---|| |    | ||---+---||  " << endl;
            cout << "                                                                                       ||__|___|| |   o| ||___|___||  " << endl;
            cout << "                                                                                       |========| |____| |=========|  " << endl;
            cout << "                                                                                      (^^-^^^^^-|________|-^^^--^^^)  " << endl;
            cout << "                                                                                      (,, , ,, ,/________\\,,,, ,, ,) " << endl;
            cout << "                                                                                     ','',,,,' /__________\\,,,',',;; " << endl;
        

        cout << "Presione ENTER para continuar...";
        cin.ignore().get();            return 0;
      } else if (gameover){
        system("clear");
      for (int i = 0; i < 8; i++) 
      {cout << "                                                                                                                        " << endl;}
        cout << "                 |  _ \\| ____|  _ \\|  _ \\_ _/ ___|_   _| ____|  _ / /                                                " << endl;
        cout << "                 | |_) |  _| | |_) | | | | |\\___ \\ | | |  _|   (_) |                                                  " << endl;
        cout << "                 |  __/| |___|  _ <| |_| | | ___) || | | |___   _| |                                                    " << endl;
        cout << "                 |_|   |_____|_| \\_\\____/___|____/ |_| |_____| (_) |                                                  " << endl;
        cout << "                                                                 \\_\\                                                 " << endl; 
        cout << "                                                                                  ⠀⣠⣶⣿⣿⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀" << endl;
        cout << "                           Quizas la proxima!                                     ⠀⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠹⢿⣿⣿⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⡏⢀⣀⡀⠀⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠀⣠⣤⣦⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠿⣟⣋⣼⣽⣾⣽⣦⡀⠀⠀⠀" << endl;
        cout << "                                                                                  ⢀⣼⣿⣷⣾⡽⡄⠀⠀⠀⠀⠀⠀⠀⣴⣶⣶⣿⣿⣿⡿⢿⣟⣽⣾⣿⣿⣦⠀⠀" << endl;
        cout << "                                                                                  ⣸⣿⣿⣾⣿⣿⣮⣤⣤⣤⣤⡀⠀⠀⠻⣿⡯⠽⠿⠛⠛⠉⠉⢿⣿⣿⣿⣿⣷⡀" << endl;
        cout << "                                                                                  ⣿⣿⢻⣿⣿⣿⣛⡿⠿⠟⠛⠁⣀⣠⣤⣤⣶⣶⣶⣶⣷⣶⠀⠀⠻⣿⣿⣿⣿⣇" << endl;
        cout << "                                                                                  ⢻⣿⡆⢿⣿⣿⣿⣿⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠟⠀⣠⣶⣿⣿⣿⣿⡟" << endl;
        cout << "                                                                                  ⠈⠛⠃⠈⢿⣿⣿⣿⣿⣿⣿⠿⠟⠛⠋⠉⠁⠀⠀⠀⠀⣠⣾⣿⣿⣿⠟⠋⠁⠀" << endl;
        cout << "                                                                                  ⠀⠀⠀⠀⠀⠙⢿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⠟⠁⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠀⠀⠀⠀⠀⢸⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠀⠀⠀⠀⠀⣼⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀" << endl;
        cout << "                                                                                  ⠀⠀⠀⠀⠀⠀⠻⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀" << endl;

      cout << "Presione ENTER para continuar...";
      cin.ignore().get();
      }

     
        }
        
    }

    system("clear");
    cout << "Hasta la próxima!" << endl;
  
    return 0;
  
  }

 
  
